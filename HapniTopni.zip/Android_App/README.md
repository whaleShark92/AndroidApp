# Android_App
Making a food restaurant using Android Studio - Java and the local SQLite database.

A lot of time and effort was spent on this project,
but every day I got better and better, I learned a lot in android studio.

I think so far I have a fully working app that always has more to add.
Something I can add soon is the favorites-fragment and its view and adapter. 
Then saving favourite products for each user in the database.

<p align="center">
<img src="https://user-images.githubusercontent.com/104200628/206855659-d1cffa5e-792c-49af-b402-12e0439daf1d.jpg" width="200" height="400" />
  
<img src="https://user-images.githubusercontent.com/104200628/206855658-bcbe4887-369b-4b68-8cd9-dd6b8c7307d7.jpg" width="200" height="400" />
  
<img src="https://user-images.githubusercontent.com/104200628/206855656-83398f17-1dbe-4957-b8d9-932474e46939.jpg" width="200" height="400" />
  
<img src="https://user-images.githubusercontent.com/104200628/206856432-708fa20e-69f3-4a68-bf5c-40b41558c725.jpg" width="200" height="400" />

<img src="https://user-images.githubusercontent.com/104200628/206855657-44c309a0-fb8e-4967-ab32-935248aced7d.jpg" width="200" height="400" />

<img src="https://user-images.githubusercontent.com/104200628/206856439-61e54f69-6472-4b96-9ceb-be022807100b.jpg" width="200" height="400" />

<img src="https://user-images.githubusercontent.com/104200628/206856233-cd628a23-fee9-45a2-a94a-dba89e97dd83.jpg" width="200" height="400" />
</p>
